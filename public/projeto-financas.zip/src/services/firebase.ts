/**
 * =========================================================================================
 * BANCO DE DADOS NA NUVEM (FIREBASE FIRESTORE) - CÓDIGO DEFINITIVO
 * =========================================================================================
 * 1. Carregamento seguro e assíncrono em segundo plano (Zero tela branca).
 * 2. Persistência local obrigatória ('browserLocalPersistence').
 * 3. Deleção definitiva na nuvem com deleteDoc e tombstones anti-ressurgimento.
 * =========================================================================================
 */

import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import {
  getAuth,
  setPersistence,
  browserLocalPersistence,
  GoogleAuthProvider,
  signInWithPopup,
  signInWithRedirect,
  getRedirectResult,
  signOut,
  onAuthStateChanged,
  User as FirebaseUser,
  Auth,
} from 'firebase/auth';
import {
  getFirestore,
  doc,
  collection,
  setDoc,
  getDoc,
  getDocs,
  deleteDoc,
  writeBatch,
  Firestore,
} from 'firebase/firestore';
import appletConfig from '../../firebase-applet-config.json';
import {
  Transaction,
  Category,
  UserProfile,
  RecurringExpenseRule,
} from '../types/finance';

// 2. CONFIGURAÇÃO OFICIAL DO FIREBASE:
export const firebaseConfig = {
  apiKey: "AIzaSyDLxKnZW-_9J8RAspiA7ul7gtE7F63wr_M",
  authDomain: "impressive-superstate-csmzh.firebaseapp.com",
  projectId: "impressive-superstate-csmzh",
  storageBucket: "impressive-superstate-csmzh.firebasestorage.app",
  messagingSenderId: "1079469168199",
  appId: "1:1079469168199:web:d58392f19152a1c698c362"
};

// 1. TRATAMENTO DE ERROS E INICIALIZAÇÃO SEGURA (TRY / CATCH):
let appInstance: FirebaseApp | null = null;
let dbInstance: Firestore | null = null;
let authInstance: Auth | null = null;
let googleProviderInstance: GoogleAuthProvider | null = null;
let isFirebaseAvailable = false;

try {
  if (!firebaseConfig.apiKey || firebaseConfig.apiKey.includes("COLE_AQUI")) {
    console.warn('[Firebase] Chaves não configuradas. Operando 100% no Modo Local.');
    isFirebaseAvailable = false;
  } else {
    appInstance = !getApps().length ? initializeApp(firebaseConfig) : getApp();

    try {
      dbInstance = getFirestore(appInstance, appletConfig.firestoreDatabaseId);
    } catch (errDb) {
      console.warn('[Firestore] Inicialização em modo local:', errDb);
      dbInstance = null;
    }

    try {
      authInstance = getAuth(appInstance);
      // Configura persistência local permanente para manter o usuário sempre conectado
      setPersistence(authInstance, browserLocalPersistence)
        .then(() => {
          console.log('[FirebaseAuth] Persistência permanente (browserLocalPersistence) configurada com sucesso.');
        })
        .catch((errPersist) => {
          console.warn('[FirebaseAuth] Aviso ao configurar persistência permanente:', errPersist);
        });
      try {
        authInstance.useDeviceLanguage();
      } catch {}
      googleProviderInstance = new GoogleAuthProvider();
      googleProviderInstance.setCustomParameters({ prompt: 'select_account' });

      // Captura inicial do retorno do redirecionamento do Google (signInWithRedirect)
      getRedirectResult(authInstance)
        .then((redirectUser) => {
          if (redirectUser?.user) {
            console.log('[FirebaseAuth] Usuário autenticado com sucesso pós-redirecionamento:', redirectUser.user.email);
          }
        })
        .catch((redirectErr) => {
          console.warn('[FirebaseAuth] Aviso seguro no getRedirectResult inicial:', redirectErr);
        });
    } catch (errAuth) {
      console.warn('[FirebaseAuth] Inicialização em modo local:', errAuth);
      authInstance = null;
      googleProviderInstance = null;
    }

    isFirebaseAvailable = Boolean(appInstance && authInstance);
  }
} catch (e) {
  console.warn('[Firebase] Operando 100% no Armazenamento Local Seguro:', e);
  isFirebaseAvailable = false;
  appInstance = null;
  dbInstance = null;
  authInstance = null;
  googleProviderInstance = null;
}

export const app = appInstance;
export const db = dbInstance;
export const auth = authInstance;
export const googleProvider = googleProviderInstance;
export { isFirebaseAvailable };

// Função para detectar smartphones, tablets e webviews móveis
export function isMobileDevice(): boolean {
  if (typeof window === 'undefined' || typeof navigator === 'undefined') return false;
  return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
}

// Captura segura do resultado de redirect do Google no carregamento da aplicação
export async function checkRedirectResult(): Promise<FirebaseUser | null> {
  if (!authInstance) return null;
  try {
    const result = await getRedirectResult(authInstance);
    if (result && result.user) {
      console.log('[FirebaseAuth] Login capturado com sucesso via redirect:', result.user.email);
      return result.user;
    }
    return null;
  } catch (err: any) {
    console.warn('[FirebaseAuth] Erro seguro ao verificar getRedirectResult:', err);
    return null;
  }
}

// 1. Google Sign-In Oficial 1-Clique (Popup com fallback limpo para Redirect)
export async function loginWithGoogle(): Promise<FirebaseUser | null> {
  if (!authInstance || !googleProviderInstance) {
    throw new Error('Serviço de autenticação temporariamente indisponível. Operando no modo local.');
  }

  try {
    // Garante a persistência local permanente para manter o usuário sempre logado no celular
    try {
      await setPersistence(authInstance, browserLocalPersistence);
    } catch (persistErr) {
      console.warn('[FirebaseAuth] Aviso ao reforçar persistência:', persistErr);
    }

    // Tenta primeiro signInWithPopup (padrão desktop e navegadores modernos)
    try {
      const result = await signInWithPopup(authInstance, googleProviderInstance);
      return result.user;
    } catch (popupErr: any) {
      console.warn('[FirebaseAuth] Popup falhou ou foi bloqueado. Verificando fallback...', popupErr);
      const code = popupErr?.code || '';
      const message = (popupErr?.message || '').toLowerCase();

      // Detecta se pop-up foi bloqueado, fechado ou se estamos em dispositivo móvel/webview
      const isBlocked =
        code === 'auth/popup-blocked' ||
        code === 'auth/popup-closed-by-user' ||
        code === 'auth/cancelled-popup-request' ||
        message.includes('popup') ||
        isMobileDevice();

      if (isBlocked) {
        console.log('[FirebaseAuth] Executando fallback seguro para signInWithRedirect...');
        await signInWithRedirect(authInstance, googleProviderInstance);
        return null;
      }

      throw popupErr;
    }
  } catch (err: any) {
    console.error('[FirebaseAuth] Erro no fluxo de autenticação Google:', err);
    throw err;
  }
}

// Desconectar Sessão
export async function logoutUser(): Promise<void> {
  if (!authInstance) return;
  try {
    await signOut(authInstance);
  } catch (err) {
    console.warn('[FirebaseAuth] Erro no logout:', err);
  }
}

// Observador onAuthStateChanged para Reconhecimento Imediato
export function subscribeToAuth(callback: (user: FirebaseUser | null) => void): () => void {
  if (!authInstance) {
    callback(null);
    return () => {};
  }
  try {
    return onAuthStateChanged(
      authInstance,
      (user) => {
        callback(user);
      },
      (error) => {
        console.warn('[FirebaseAuth] Erro observador de sessão:', error);
        callback(null);
      }
    );
  } catch (err) {
    console.warn('[FirebaseAuth] Falha ao registrar observador:', err);
    callback(null);
    return () => {};
  }
}

// ==========================================
// Estrutura de Sincronização e Lixeira Real
// ==========================================

export interface UserSecurityCloudData {
  pin?: string | null;
  pinEnabled?: boolean;
  biometricEnabled?: boolean;
  biometricRegistered?: boolean;
  biometricType?: string;
  biometricDate?: string;
  biometricCredentialId?: string | null;
}

export interface UserCloudData {
  transactions: Transaction[];
  incomeCategories: Category[];
  expenseCategories: Category[];
  budgets: Record<string, number>;
  defaultBudget: number;
  categoryBudgets: Record<string, number>;
  userProfile?: UserProfile;
  recurringRules: RecurringExpenseRule[];
  security?: UserSecurityCloudData;
  deletedItemIds?: string[];
}

/**
 * Sincroniza lançamentos, perfil e configurações no Firestore
 */
export async function syncUserDataToCloud(userId: string, data: UserCloudData): Promise<void> {
  if (!userId || !dbInstance) return;

  try {
    // 1. Documento Raiz do Usuário
    const userDocRef = doc(dbInstance, 'users', userId);
    await setDoc(
      userDocRef,
      {
        userId,
        name: data.userProfile?.name || 'Usuário',
        managerName: data.userProfile?.managerName || data.userProfile?.name || 'Usuário',
        login: data.userProfile?.login || '@usuario',
        pixKey: data.userProfile?.pixKey || '',
        avatarUrl: data.userProfile?.avatarUrl || '',
        avatarColor: data.userProfile?.avatarColor || '#7dd3fc',
        bio: data.userProfile?.bio || '',
        joinedDate: data.userProfile?.joinedDate || 'Setembro 2026',
        themeColor: data.userProfile?.themeColor || 'sky',
        ...(data.security ? { security: data.security } : {}),
        ...(data.deletedItemIds && data.deletedItemIds.length > 0 ? { deletedItemIds: data.deletedItemIds } : {}),
        updatedAt: new Date().toISOString(),
      },
      { merge: true }
    );

    // Subcoleção de Perfil
    if (data.userProfile) {
      const profileRef = doc(dbInstance, 'users', userId, 'profile', 'current');
      await setDoc(
        profileRef,
        {
          userId,
          name: data.userProfile.name,
          managerName: data.userProfile.managerName || data.userProfile.name,
          login: data.userProfile.login,
          pixKey: data.userProfile.pixKey || '',
          avatarUrl: data.userProfile.avatarUrl || '',
          avatarColor: data.userProfile.avatarColor || '#7dd3fc',
          bio: data.userProfile.bio || '',
          joinedDate: data.userProfile.joinedDate,
          themeColor: data.userProfile.themeColor || 'sky',
          updatedAt: new Date().toISOString(),
        },
        { merge: true }
      );
    }

    // 2. Orçamentos
    const budgetRef = doc(dbInstance, 'users', userId, 'budgetConfig', 'current');
    await setDoc(
      budgetRef,
      {
        userId,
        budgets: data.budgets,
        defaultBudget: data.defaultBudget,
        categoryBudgets: data.categoryBudgets,
        updatedAt: new Date().toISOString(),
      },
      { merge: true }
    );

    // 3. Categorias
    const allCategories = [...data.incomeCategories, ...data.expenseCategories];
    const catBatch = writeBatch(dbInstance);
    for (const cat of allCategories) {
      const catRef = doc(dbInstance, 'users', userId, 'categories', cat.id);
      catBatch.set(catRef, { ...cat, userId }, { merge: true });
    }
    await catBatch.commit();

    // 4. Lançamentos (em lotes)
    const txChunks: Transaction[][] = [];
    const chunkSize = 200;
    for (let i = 0; i < data.transactions.length; i += chunkSize) {
      txChunks.push(data.transactions.slice(i, i + chunkSize));
    }

    for (const chunk of txChunks) {
      const txBatch = writeBatch(dbInstance);
      for (const tx of chunk) {
        const txRef = doc(dbInstance, 'users', userId, 'transactions', tx.id);
        txBatch.set(txRef, { ...tx, userId }, { merge: true });
      }
      await txBatch.commit();
    }

    // 5. Regras Recorrentes
    if (data.recurringRules.length > 0) {
      const ruleBatch = writeBatch(dbInstance);
      for (const rule of data.recurringRules) {
        const ruleRef = doc(dbInstance, 'users', userId, 'recurringRules', rule.id);
        ruleBatch.set(ruleRef, { ...rule, userId }, { merge: true });
      }
      await ruleBatch.commit();
    }
  } catch (error) {
    console.warn('[Firestore Sync] Operação em segundo plano:', error);
  }
}

/**
 * Busca dados da nuvem garantindo que itens apagados (deletedItemIds) nunca retornem
 */
export async function fetchUserDataFromCloud(userId: string): Promise<UserCloudData | null> {
  if (!userId || !dbInstance) return null;

  try {
    const userDocRef = doc(dbInstance, 'users', userId);
    const userDocSnap = await getDoc(userDocRef);

    let security: UserSecurityCloudData | undefined = undefined;
    let deletedItemIds: string[] = [];
    let rootUserData: any = null;

    if (userDocSnap.exists()) {
      rootUserData = userDocSnap.data();
      if (rootUserData.security) {
        security = rootUserData.security as UserSecurityCloudData;
      }
      if (rootUserData.deletedItemIds && Array.isArray(rootUserData.deletedItemIds)) {
        deletedItemIds = rootUserData.deletedItemIds;
      }
    }

    const deletedSet = new Set(deletedItemIds);

    // Perfil
    const profileRef = doc(dbInstance, 'users', userId, 'profile', 'current');
    const profileSnap = await getDoc(profileRef);
    let userProfile: UserProfile | undefined = undefined;

    if (profileSnap.exists()) {
      userProfile = profileSnap.data() as UserProfile;
    } else if (rootUserData?.name) {
      userProfile = {
        name: rootUserData.name,
        managerName: rootUserData.managerName || rootUserData.name,
        login: rootUserData.login || '@usuario',
        pixKey: rootUserData.pixKey || '',
        avatarUrl: rootUserData.avatarUrl || '',
        avatarColor: rootUserData.avatarColor || '#7dd3fc',
        bio: rootUserData.bio || '',
        joinedDate: rootUserData.joinedDate || 'Setembro 2026',
        themeColor: rootUserData.themeColor || 'sky',
      };
    }

    // Orçamento
    const budgetRef = doc(dbInstance, 'users', userId, 'budgetConfig', 'current');
    const budgetSnap = await getDoc(budgetRef);
    const budgetConfig = budgetSnap.exists() ? budgetSnap.data() : null;

    // Categorias (exclui permanentemente itens apagados)
    const catSnaps = await getDocs(collection(dbInstance, 'users', userId, 'categories'));
    const fetchedCategories: Category[] = [];
    catSnaps.forEach((docSnap) => {
      const c = docSnap.data() as Category;
      if (!deletedSet.has(c.id)) {
        fetchedCategories.push(c);
      } else {
        deleteDoc(docSnap.ref).catch(() => {});
      }
    });

    // Lançamentos (exclui permanentemente itens apagados)
    const txSnaps = await getDocs(collection(dbInstance, 'users', userId, 'transactions'));
    const fetchedTransactions: Transaction[] = [];
    txSnaps.forEach((docSnap) => {
      const t = docSnap.data() as Transaction;
      if (!deletedSet.has(t.id)) {
        fetchedTransactions.push(t);
      } else {
        deleteDoc(docSnap.ref).catch(() => {});
      }
    });

    // Regras Recorrentes (exclui permanentemente itens apagados)
    const ruleSnaps = await getDocs(collection(dbInstance, 'users', userId, 'recurringRules'));
    const fetchedRules: RecurringExpenseRule[] = [];
    ruleSnaps.forEach((docSnap) => {
      const r = docSnap.data() as RecurringExpenseRule;
      if (!deletedSet.has(r.id)) {
        fetchedRules.push(r);
      } else {
        deleteDoc(docSnap.ref).catch(() => {});
      }
    });

    return {
      transactions: fetchedTransactions,
      incomeCategories: fetchedCategories.filter((c) => c.type === 'income'),
      expenseCategories: fetchedCategories.filter((c) => c.type === 'expense'),
      budgets: budgetConfig?.budgets || {},
      defaultBudget: budgetConfig?.defaultBudget ?? 3500,
      categoryBudgets: budgetConfig?.categoryBudgets || {},
      userProfile,
      recurringRules: fetchedRules,
      security,
      deletedItemIds,
    };
  } catch (error) {
    console.warn('[Firestore Fetch] Fallback para armazenamento local:', error);
    return null;
  }
}

// 3. EXCLUSÃO DEFINITIVA (LIXEIRA REAL COM deleteDoc):

/**
 * Exclui lançamento da nuvem imediatamente
 */
export async function deleteTransactionFromCloud(userId: string, transactionId: string): Promise<void> {
  if (!userId || !transactionId || !dbInstance) return;
  try {
    const txRef = doc(dbInstance, 'users', userId, 'transactions', transactionId);
    await deleteDoc(txRef);
  } catch (error) {
    console.warn('[Firestore deleteDoc] Erro ao excluir transação:', error);
  }
}

/**
 * Exclui categoria da nuvem imediatamente
 */
export async function deleteCategoryFromCloud(userId: string, categoryId: string): Promise<void> {
  if (!userId || !categoryId || !dbInstance) return;
  try {
    const catRef = doc(dbInstance, 'users', userId, 'categories', categoryId);
    await deleteDoc(catRef);
  } catch (error) {
    console.warn('[Firestore deleteDoc] Erro ao excluir categoria:', error);
  }
}

/**
 * Exclui regra recorrente da nuvem imediatamente
 */
export async function deleteRecurringRuleFromCloud(userId: string, ruleId: string): Promise<void> {
  if (!userId || !ruleId || !dbInstance) return;
  try {
    const ruleRef = doc(dbInstance, 'users', userId, 'recurringRules', ruleId);
    await deleteDoc(ruleRef);
  } catch (error) {
    console.warn('[Firestore deleteDoc] Erro ao excluir regra:', error);
  }
}

/**
 * Salva perfil e credenciais de segurança diretamente em users/{userId}
 */
export async function saveProfileAndSecurityToCloud(
  userId: string,
  profile: UserProfile,
  security?: UserSecurityCloudData
): Promise<void> {
  if (!userId || !dbInstance) return;
  try {
    const userDocRef = doc(dbInstance, 'users', userId);
    await setDoc(
      userDocRef,
      {
        userId,
        name: profile.name,
        managerName: profile.managerName || profile.name,
        login: profile.login,
        pixKey: profile.pixKey || '',
        avatarUrl: profile.avatarUrl || '',
        avatarColor: profile.avatarColor || '#7dd3fc',
        bio: profile.bio || '',
        joinedDate: profile.joinedDate,
        themeColor: profile.themeColor || 'sky',
        ...(security ? { security } : {}),
        updatedAt: new Date().toISOString(),
      },
      { merge: true }
    );
  } catch (error) {
    console.warn('[Firestore Profile] Erro ao salvar perfil:', error);
  }
}

/**
 * Zera todas as transações na nuvem para o usuário
 */
export async function clearAllTransactionsFromCloud(userId: string): Promise<void> {
  if (!userId || !dbInstance) return;
  try {
    const txSnaps = await getDocs(collection(dbInstance, 'users', userId, 'transactions'));
    const batch = writeBatch(dbInstance);
    txSnaps.forEach((docSnap) => {
      batch.delete(docSnap.ref);
    });

    const ruleSnaps = await getDocs(collection(dbInstance, 'users', userId, 'recurringRules'));
    ruleSnaps.forEach((docSnap) => {
      batch.delete(docSnap.ref);
    });

    await batch.commit();
  } catch (error) {
    console.warn('[Firestore Clear] Erro ao zerar histórico:', error);
  }
}
